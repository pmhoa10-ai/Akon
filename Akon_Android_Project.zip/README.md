# Akon • 60 ngày

Ứng dụng Android theo dõi chương trình Akon 60 ngày.

## Cách build APK bằng GitHub
1. Tạo repo GitHub tên `Akon`.
2. Upload toàn bộ thư mục trong file ZIP này lên nhánh `main`.
3. Mở tab **Actions**.
4. Chọn workflow **Build Akon APK**.
5. Bấm **Run workflow** nếu workflow chưa tự chạy.
6. Khi hoàn tất, mở lần chạy thành công và tải artifact **akon-debug-apk**.

## Lưu ý
- Ngày 58–60 hiện để `Chưa có dữ liệu`, không tự bịa lịch.
- Nhắc lịch mặc định 19:00.
- Android 13+ sẽ hỏi quyền thông báo.
- Các URL trong app là đúng các link đã được cung cấp.

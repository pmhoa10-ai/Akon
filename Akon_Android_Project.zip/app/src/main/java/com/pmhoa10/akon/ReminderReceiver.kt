package com.pmhoa10.akon

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) return

        val prefs = context.getSharedPreferences("akon", Context.MODE_PRIVATE)
        val start = prefs.getLong("start_millis", -1L)
        var day = 0
        if (start > 0) {
            val startCal = java.util.Calendar.getInstance().apply { timeInMillis = start }
            val now = java.util.Calendar.getInstance()
            startCal.set(java.util.Calendar.HOUR_OF_DAY, 0); startCal.set(java.util.Calendar.MINUTE, 0)
            startCal.set(java.util.Calendar.SECOND, 0); startCal.set(java.util.Calendar.MILLISECOND, 0)
            now.set(java.util.Calendar.HOUR_OF_DAY, 0); now.set(java.util.Calendar.MINUTE, 0)
            now.set(java.util.Calendar.SECOND, 0); now.set(java.util.Calendar.MILLISECOND, 0)
            day = ((now.timeInMillis - startCal.timeInMillis) / 86400000L).toInt() + 1
        }

        val text = if (day in 1..60) "Đến giờ tập: Ngày $day" else "Đến giờ kiểm tra lịch Akon"
        val channelId = "akon_reminder"

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Akon nhắc lịch", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Akon • Nhắc lịch")
            .setContentText(text)
            .setAutoCancel(true)
            .build()

        manager.notify(1001, notification)
    }
}

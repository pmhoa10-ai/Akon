package com.pmhoa10.akon

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("akon", MODE_PRIVATE) }
    private val schedule = listOf(
        "Buổi 1","Buổi 2","Buổi 3","REST","Buổi 4","Buổi 5","Buổi 6","REST",
        "Buổi 7","Buổi 8","Buổi 9","REST","Buổi 10","Buổi 11","Buổi 12","REST",
        "Buổi 13","Buổi 14","Buổi 15","REST","Buổi 16","Buổi 17","Buổi 18","REST",
        "Buổi 19","Buổi 20","Buổi 21","Buổi 22","REST","Buổi 23","Buổi 24","Buổi 25",
        "Buổi 26","REST","Buổi 27","Buổi 28","Buổi 29","Buổi 30","REST",
        "Buổi 1 + Buổi 2","Buổi 3 + Buổi 4","Buổi 5 + Buổi 6","Buổi 7 + Buổi 8","REST",
        "Buổi 9 + Buổi 10","Buổi 11 + Buổi 12","Buổi 13 + Buổi 14","Buổi 15 + Buổi 16","REST",
        "Buổi 17 + Buổi 18","Buổi 19 + Buổi 20","Buổi 21 + Buổi 22","REST",
        "Buổi 23 + Buổi 24","Buổi 25 + Buổi 26","Buổi 27 + Buổi 28","Buổi 29 + Buổi 30",
        "Chưa có dữ liệu","Chưa có dữ liệu","Chưa có dữ liệu"
    )

    private val playlist = "https://youtube.com/playlist?list=PLbcgW9WsYf0GZA3OdCVqM2c7evWIP_N9T&si=E36LsGI5T4zGjfxa"
    private val hang = "https://youtu.be/HjOn927LayE"
    private val alternative = "https://youtu.be/RKIfXm62zcs?si=b0-FzeKWJQW-Qc1R"
    private val original = "https://youtu.be/kqsNqZOwIB0?si=FvaPTQ0omYuocByO"
    private val facebook = "https://www.facebook.com/share/g/1FGifmCA9j/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        scheduleReminder()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 40)
            setBackgroundColor(0xFF111111.toInt())
        }
        scroll.addView(box)

        val title = TextView(this).apply {
            text = "AKON • 60 NGÀY"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 20, 0, 6)
        }
        box.addView(title)

        val startDate = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFBDBDBD.toInt())
        }
        box.addView(startDate)

        val date = prefs.getString("start_date", null)
        if (date == null) {
            startDate.text = "Chưa chọn ngày bắt đầu"
        } else {
            startDate.text = "Bắt đầu: $date"
        }

        val choose = Button(this).apply {
            text = "CHỌN NGÀY BẮT ĐẦU"
            setOnClickListener { pickStartDate(startDate) }
        }
        box.addView(choose)

        val today = currentDay()
        val current = TextView(this).apply {
            text = if (today in 1..60) "Hôm nay: NGÀY $today • ${schedule[today-1]}"
                   else "Hôm nay chưa nằm trong chu kỳ 60 ngày"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 24, 0, 18)
        }
        box.addView(current)

        val progress = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFBDBDBD.toInt())
        }
        box.addView(progress)

        val dayContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        box.addView(dayContainer)

        fun refreshProgress() {
            val done = (1..60).count { prefs.getBoolean("done_$it", false) }
            progress.text = "Tiến độ: $done/60 ngày"
        }

        for (day in 1..60) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 8, 0, 8)
            }
            val cb = CheckBox(this).apply {
                text = "Ngày $day"
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
                isChecked = prefs.getBoolean("done_$day", false)
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean("done_$day", checked).apply()
                    refreshProgress()
                }
            }
            row.addView(cb, LinearLayout.LayoutParams(0, -2, 1f))

            val session = TextView(this).apply {
                text = schedule[day-1]
                textSize = 15f
                setTextColor(if (schedule[day-1] == "REST") 0xFF80CBC4.toInt() else 0xFFE0E0E0.toInt())
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(session, LinearLayout.LayoutParams(0, -2, 1.2f))
            dayContainer.addView(row)
        }
        refreshProgress()

        addLinkButton(box, "▶ MỞ PLAYLIST 30 BUỔI", playlist)
        addLinkButton(box, "⛓ BÀI TREO XÀ", hang)
        addLinkButton(box, "↔ BÀI THAY THẾ / GIÃN CƠ", alternative)
        addLinkButton(box, "ℹ CHƯƠNG TRÌNH GỐC", original)
        addLinkButton(box, "👥 NHÓM FACEBOOK", facebook)

        val note = TextView(this).apply {
            text = "Nhắc nhở mặc định: 19:00 mỗi ngày. Ngày 58–60 đang để trống vì chưa có dữ liệu."
            textSize = 14f
            setTextColor(0xFF9E9E9E.toInt())
            setPadding(0, 24, 0, 0)
        }
        box.addView(note)

        setContentView(scroll)
    }

    private fun addLinkButton(parent: LinearLayout, label: String, url: String) {
        parent.addView(Button(this).apply {
            text = label
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        })
    }

    private fun pickStartDate(label: TextView) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val selected = Calendar.getInstance().apply { set(y, m, d) }
            val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val value = fmt.format(selected.time)
            prefs.edit().putString("start_date", value)
                .putLong("start_millis", selected.timeInMillis).apply()
            label.text = "Bắt đầu: $value"
            buildUi()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun currentDay(): Int {
        val start = prefs.getLong("start_millis", -1L)
        if (start <= 0) return 0
        val startCal = Calendar.getInstance().apply { timeInMillis = start }
        val now = Calendar.getInstance()
        startCal.set(Calendar.HOUR_OF_DAY, 0); startCal.set(Calendar.MINUTE, 0)
        startCal.set(Calendar.SECOND, 0); startCal.set(Calendar.MILLISECOND, 0)
        now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0)
        now.set(Calendar.SECOND, 0); now.set(Calendar.MILLISECOND, 0)
        val diff = ((now.timeInMillis - startCal.timeInMillis) / 86400000L).toInt()
        return diff + 1
    }

    private fun scheduleReminder() {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 19)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
        }
        alarm.setInexactRepeating(
            AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi
        )
    }
}
